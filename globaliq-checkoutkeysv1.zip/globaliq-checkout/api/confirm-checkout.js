// /api/confirm-checkout.js
//
// Step 2 of checkout. Called immediately after Stripe.js confirms the
// SetupIntent on the frontend (i.e. the payment method has been verified
// and saved to the customer). This endpoint:
//
//   1. Charges the customer's saved payment method $1.00 one-time
//      (your "Global IQ Trial" price) for the 7-day trial.
//   2. Creates a subscription on the "Global IQ Membership" price
//      ($29.99/month) with a 7-day trial, so the FIRST recurring charge
//      happens automatically 7 days from now, then every month after
//      until canceled.
//
// All amounts/prices are pulled from your existing Stripe Price objects,
// never hardcoded here, so changing the price in the Stripe Dashboard is
// reflected automatically.

import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-06-20",
});

// Set these to your real Stripe Price IDs (Dashboard -> Product catalog).
// They are server-side env vars (not the publishable key) so they're safe
// to keep here, but we still read them from env vars rather than hardcoding
// so you can change them without touching code.
const TRIAL_PRICE_ID = process.env.STRIPE_TRIAL_PRICE_ID; // Global IQ Trial: $1 one-time
const MEMBERSHIP_PRICE_ID = process.env.STRIPE_MEMBERSHIP_PRICE_ID; // Global IQ Membership: $29.99/month

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { customerId, paymentMethodId } = req.body || {};

    if (!customerId || !paymentMethodId) {
      return res.status(400).json({ error: "Missing customerId or paymentMethodId." });
    }
    if (!TRIAL_PRICE_ID || !MEMBERSHIP_PRICE_ID) {
      console.error("Missing STRIPE_TRIAL_PRICE_ID or STRIPE_MEMBERSHIP_PRICE_ID env vars.");
      return res.status(500).json({ error: "Server is not configured correctly." });
    }

    // Make sure this payment method is the customer's default, so the
    // subscription (created below) and the trial charge both use it
    // automatically without us passing card details around.
    await stripe.paymentMethods.attach(paymentMethodId, { customer: customerId }).catch((err) => {
      // Already attached is fine (e.g. Link/Cash App may auto-attach).
      if (err.code !== "resource_already_exists" && err.statusCode !== 400) throw err;
    });

    await stripe.customers.update(customerId, {
      invoice_settings: { default_payment_method: paymentMethodId },
    });

    // 1) Charge $1.00 today for the trial via a PaymentIntent against the
    //    "Global IQ Trial" price. We pull the price object to know the exact
    //    amount/currency rather than hardcoding "100" / "usd".
    const trialPrice = await stripe.prices.retrieve(TRIAL_PRICE_ID);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: trialPrice.unit_amount,
      currency: trialPrice.currency,
      customer: customerId,
      payment_method: paymentMethodId,
      off_session: false,
      confirm: true,
      description: "Global IQ Trial - $1, 7-day access",
      metadata: { type: "globaliq_trial_charge" },
    });

    if (paymentIntent.status !== "succeeded") {
      return res.status(402).json({
        error: "Your $1 trial payment could not be completed.",
        status: paymentIntent.status,
      });
    }

    // 2) Create the recurring membership subscription, set to trial for 7
    //    days. Stripe will NOT bill anything else now — the first $29.99
    //    charge fires automatically when the trial ends in 7 days, then
    //    monthly after that until the subscription is canceled.
    const trialEnd = Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60;

    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: MEMBERSHIP_PRICE_ID }],
      trial_end: trialEnd,
      default_payment_method: paymentMethodId,
      payment_settings: {
        payment_method_types: ["card", "cashapp", "link"],
        save_default_payment_method: "on_subscription",
      },
      metadata: { type: "globaliq_membership" },
    });

    return res.status(200).json({
      success: true,
      subscriptionId: subscription.id,
      trialEndsAt: trialEnd,
      paymentIntentId: paymentIntent.id,
    });
  } catch (err) {
    console.error("confirm-checkout error:", err);
    return res.status(500).json({ error: err.message || "Checkout failed. Please try again." });
  }
}
