// /api/create-setup-intent.js
//
// Step 1 of checkout. Called when the customer reaches the payment box.
// Creates (or reuses) a Stripe Customer for this email, then creates a
// SetupIntent so the Stripe Payment Element can securely collect and save
// a payment method (card, Apple Pay, Google Pay, Cash App Pay, Link).
//
// IMPORTANT: no card data ever touches this server or your frontend code.
// Stripe.js handles all of that in the browser and only ever sends Stripe
// a payment_method id / token.

import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-06-20",
});

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { email } = req.body || {};

    if (!email || typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "A valid email is required." });
    }

    // Reuse an existing Stripe customer for this email if one already exists,
    // so repeat visitors / abandoned checkouts don't create duplicate customers.
    const existing = await stripe.customers.list({ email, limit: 1 });
    const customer =
      existing.data[0] ||
      (await stripe.customers.create({
        email,
        metadata: { source: "globaliq_checkout" },
      }));

    // SetupIntent: collects + saves a payment method for future off-session
    // billing, without charging anything yet. We charge the $1 trial fee
    // separately in /api/confirm-checkout once the payment method is attached.
    const setupIntent = await stripe.setupIntents.create({
      customer: customer.id,
      payment_method_types: ["card", "cashapp", "link"],
      usage: "off_session",
    });

    return res.status(200).json({
      clientSecret: setupIntent.client_secret,
      customerId: customer.id,
    });
  } catch (err) {
    console.error("create-setup-intent error:", err);
    return res.status(500).json({ error: "Unable to start checkout. Please try again." });
  }
}
