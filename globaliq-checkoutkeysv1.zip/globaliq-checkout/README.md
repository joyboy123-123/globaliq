# Global IQ Checkout — Stripe Setup

## What changed
Your checkout page design is unchanged. The payment box now uses **Stripe
Payment Element** instead of fake buttons. Card, Apple Pay, Google Pay,
Cash App Pay, and Link are all handled by Stripe inside that box — your
site never sees or stores card numbers, Apple Pay tokens, or any other
payment details. PayPal and Venmo buttons are left in place as visual
placeholders only (not wired to anything) since you're handling those
separately.

## Files
```
/public/index.html         <- your checkout page (design untouched)
/api/create-setup-intent.js <- creates Stripe customer + SetupIntent
/api/confirm-checkout.js    <- charges $1, creates the 7-day-trial subscription
/package.json
/vercel.json
/.env.example
```

## 1. Where your Stripe keys go

**Publishable key** (safe to be public) — paste it directly into
`public/index.html`. Search for this line near the top of the big
`<script>` block:

```js
const STRIPE_PUBLISHABLE_KEY = "pk_live_REPLACE_WITH_YOUR_PUBLISHABLE_KEY";
```

Replace with your real key from Stripe Dashboard → Developers → API keys
→ "Publishable key".

**Secret key and Price IDs** (must stay private) — these go in **Vercel
environment variables**, never in the HTML/JS:

1. Go to your Vercel project → Settings → Environment Variables.
2. Add:

| Name | Value | Where to find it |
|---|---|---|
| `STRIPE_SECRET_KEY` | `sk_live_...` | Stripe Dashboard → Developers → API keys |
| `STRIPE_TRIAL_PRICE_ID` | `price_...` | Stripe Dashboard → Product catalog → "Global IQ Trial" |
| `STRIPE_MEMBERSHIP_PRICE_ID` | `price_...` | Stripe Dashboard → Product catalog → "Global IQ Membership" |

3. Redeploy after adding/changing env vars (Vercel doesn't hot-reload them).

Use your **test mode** keys (`sk_test_...` / `pk_test_...`) and test Price
IDs first, confirm the flow with Stripe's test cards, then swap to live
keys when ready.

## 2. How the billing flow works

1. Customer enters email → `EmailPage` (unchanged).
2. `CheckoutPage` mounts → `PaymentBox` calls `/api/create-setup-intent`,
   which creates a Stripe Customer for that email and a SetupIntent.
3. Stripe's Payment Element renders inside your existing payment box,
   offering whatever's available (card, Apple Pay, Google Pay, Cash App
   Pay, Link) based on the customer's browser/device.
4. Customer clicks "Pay $1.00 & start trial":
   - `stripe.confirmSetup()` runs in the browser — Stripe verifies and
     saves the payment method. No card data passes through your server.
   - Your frontend then calls `/api/confirm-checkout` with the resulting
     `customerId` and `paymentMethodId`.
5. `confirm-checkout.js`:
   - Charges **$1.00 once**, immediately, using your "Global IQ Trial"
     price (so refunds/reporting in Stripe match that product).
   - Creates a **subscription** on "Global IQ Membership" ($29.99/mo)
     with `trial_end` set to 7 days from now.
   - Stripe automatically bills $29.99 the moment the trial ends, then
     every month after that, until the subscription is canceled — no
     additional code or cron job needed on your end.

## 3. Deploying

```bash
npm install
vercel deploy        # or push to GitHub if your Vercel project is linked to it
```

`vercel.json` tells Vercel to serve `public/` as static files and
`api/*.js` as serverless functions, so `public/index.html` becomes your
homepage automatically.

## 4. Testing before going live

- Use Stripe test mode keys + Stripe's test cards (e.g. `4242 4242 4242
  4242`, any future expiry, any CVC).
- In Stripe Dashboard (test mode) → Payments, confirm the $1 charge
  appears, and under Subscriptions confirm a subscription was created
  with status "trialing" and the correct trial end date (~7 days out).
- Use Stripe Dashboard's "Test clock" feature, or just wait, to confirm
  the $29.99 charge fires automatically when the trial ends.

## 5. Going live checklist
- [ ] Swap `STRIPE_PUBLISHABLE_KEY` in `index.html` to your live `pk_live_...` key
- [ ] Swap `STRIPE_SECRET_KEY` in Vercel env vars to live `sk_live_...`
- [ ] Swap `STRIPE_TRIAL_PRICE_ID` / `STRIPE_MEMBERSHIP_PRICE_ID` to your **live mode** Price IDs (test and live prices have different IDs even for the "same" product)
- [ ] Redeploy
